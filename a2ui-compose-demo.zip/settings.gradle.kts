pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "A2UIComposeDemo"
include(":app")
include(":a2ui-compose")
project(":a2ui-compose").projectDir = file("D:/projects/A2UI/android_compose")
