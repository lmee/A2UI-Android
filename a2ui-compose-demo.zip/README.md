# A2UI Compose Demo

这是一个基于Google A2UI协议的Android Compose渲染引擎实现和演示应用。

## 项目概述

A2UI (Agent-to-User Interface) 是Google开源的一个用于代理驱动界面的协议。本项目实现了：

1. **A2UI协议解析器** - 解析JSONL格式的A2UI消息
2. **Compose渲染引擎** - 将A2UI组件树渲染为Jetpack Compose UI
3. **标准组件库** - 实现了常用的UI组件（Text, Button, Card, Column, Row, TextField, List等）
4. **Demo应用** - 展示如何使用渲染引擎

## 项目结构

```
app/src/main/java/com/example/a2uidemo/
├── a2ui/
│   ├── protocol/           # A2UI协议消息定义
│   │   └── A2UIMessages.kt
│   ├── parser/             # 消息解析器
│   │   └── A2UIMessageParser.kt
│   ├── renderer/           # 渲染引擎核心
│   │   ├── A2UIRenderer.kt
│   │   └── ComponentCatalog.kt
│   ├── components/         # 标准组件实现
│   │   └── StandardComponents.kt
│   └── ui/                 # UI层
│       └── A2UISurface.kt
├── ui/theme/               # 主题配置
│   ├── Color.kt
│   ├── Theme.kt
│   └── Type.kt
├── DemoViewModel.kt        # 应用ViewModel
└── MainActivity.kt         # 主活动
```

## 核心功能

### 1. A2UI协议支持

支持以下A2UI消息类型：
- `beginRendering` - 开始渲染一个新的surface
- `surfaceUpdate` - 更新surface的组件树
- `dataModelUpdate` - 更新数据模型
- `deleteSurface` - 删除surface

### 2. 组件目录

实现了以下标准组件：

| 组件类型 | 说明 | 支持的属性 |
|---------|------|----------|
| `text` | 文本显示 | text, style (headline/title/body) |
| `button` | 按钮 | text, action, enabled |
| `column` | 垂直布局 | children, spacing |
| `row` | 水平布局 | children, spacing |
| `card` | 卡片容器 | child |
| `textField` | 文本输入框 | label, value |
| `list` | 列表 | items, itemTemplate |

### 3. 数据绑定

支持：
- 字面值（Literal values）
- 数据模型引用（JSON Pointer路径）
- 双向绑定（TextField组件）

### 4. 事件处理

支持组件动作事件：
- 按钮点击
- 文本输入变化
- 自定义动作

## A2UI协议示例

### 简单卡片示例

```json
{"type":"beginRendering","surfaceId":"demo1"}
{"type":"surfaceUpdate","surfaceId":"demo1","components":[
  {"id":"root","type":"card","properties":{"child":"content"}},
  {"id":"content","type":"column","properties":{"children":["title","button"]}},
  {"id":"title","type":"text","properties":{"text":"Welcome to A2UI"}},
  {"id":"button","type":"button","properties":{"text":"Click Me"}}
]}
{"type":"dataModelUpdate","surfaceId":"demo1","dataModel":{}}
```

### 表单示例

```json
{"type":"beginRendering","surfaceId":"form"}
{"type":"surfaceUpdate","surfaceId":"form","components":[
  {"id":"root","type":"card","properties":{"child":"form"}},
  {"id":"form","type":"column","properties":{"children":["nameField","submitButton"]}},
  {"id":"nameField","type":"textField","properties":{"label":"Name","value":{"path":"/name"}}},
  {"id":"submitButton","type":"button","properties":{"text":"Submit"}}
]}
{"type":"dataModelUpdate","surfaceId":"form","dataModel":{"name":""}}
```

## 如何使用

### 1. 加载Demo数据

应用提供了三个预设的Demo示例：
- **Simple Card** - 简单的卡片布局
- **Form** - 表单输入示例
- **List** - 列表渲染示例

点击对应按钮即可加载演示。

### 2. 集成到自己的应用

```kotlin
// 1. 创建渲染器
val renderer = A2UIRenderer()

// 2. 解析并处理A2UI消息
val messages = A2UIMessageParser.parseMessages(jsonLines)
messages.forEach { renderer.processMessage(it) }

// 3. 在Compose中渲染
A2UISurface(
    surfaceId = "your-surface-id",
    renderer = renderer,
    onAction = { componentId, actionType, context ->
        // 处理用户操作
    }
)
```

### 3. 扩展自定义组件

```kotlin
class CustomComponentRenderer : ComponentRenderer {
    @Composable
    override fun Render(
        component: Component,
        dataModel: JsonObject,
        surfaceState: SurfaceState,
        onAction: (componentId: String, actionType: String, context: JsonObject?) -> Unit
    ) {
        // 实现自定义组件渲染逻辑
    }
}

// 注册到目录
val catalog = ComponentCatalog()
catalog.register("customComponent", CustomComponentRenderer())
```

## 技术栈

- **Kotlin** - 编程语言
- **Jetpack Compose** - 现代UI工具包
- **Material 3** - Material Design组件
- **Kotlin Serialization** - JSON序列化/反序列化
- **Coroutines** - 异步处理
- **ViewModel** - 架构组件

## 构建和运行

### 前置要求

- Android Studio Hedgehog (2023.1.1) 或更高版本
- JDK 17
- Android SDK (API 24+)

### 构建步骤

1. 克隆或下载项目
2. 在Android Studio中打开项目
3. 等待Gradle同步完成
4. 运行应用（Shift + F10）

## A2UI协议规范

本实现基于A2UI v0.8规范，主要特性：

- **安全性优先** - 声明式数据格式，非可执行代码
- **LLM友好** - 扁平化组件列表，易于增量生成
- **框架无关** - 同一JSON可在不同平台渲染
- **渐进式渲染** - 支持流式更新

## 参考资源

- [A2UI官方文档](https://a2ui.org/)
- [A2UI GitHub仓库](https://github.com/google/A2UI)
- [A2UI规范](https://a2ui.org/specification/v0.8-a2ui/)

## 许可证

本项目采用Apache 2.0许可证，与A2UI协议保持一致。

## 贡献

欢迎提交Issue和Pull Request！

## 未来计划

- [ ] 支持更多组件类型（Image, Checkbox, Switch等）
- [ ] 实现SSE/WebSocket实时连接
- [ ] 添加动画和过渡效果
- [ ] 支持A2UI v0.9规范
- [ ] 性能优化和测试覆盖
- [ ] 与AI Agent集成示例

## 联系方式

如有问题或建议，请在GitHub上提Issue。
