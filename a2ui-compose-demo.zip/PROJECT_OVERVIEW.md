# A2UI Compose渲染引擎 - 项目概览

## 🎯 项目简介

这是一个完整的**A2UI (Agent-to-User Interface)** Android Compose渲染引擎实现。A2UI是Google开源的用于AI代理驱动界面的协议，本项目实现了该协议在Android平台上的完整支持。

## ✨ 核心特性

### 1. 完整的A2UI协议支持
- ✅ 支持所有A2UI v0.8消息类型
- ✅ JSONL格式消息解析
- ✅ 渐进式渲染
- ✅ 多Surface支持

### 2. 丰富的组件库
| 组件 | 说明 | 功能 |
|-----|------|------|
| Text | 文本显示 | 多种样式、数据绑定 |
| Button | 按钮 | 动作处理、状态管理 |
| TextField | 输入框 | 双向数据绑定 |
| Card | 卡片容器 | Material设计 |
| Column | 垂直布局 | 子组件排列 |
| Row | 水平布局 | 子组件排列 |
| List | 列表 | 数据驱动、模板化 |

### 3. 强大的数据绑定
- JSON Pointer路径解析
- 响应式数据更新
- 类型安全的数据访问
- 嵌套对象和数组支持

### 4. Jetpack Compose原生支持
- Material 3设计系统
- 声明式UI
- 自动重组
- 高性能渲染

## 📁 项目结构

```
a2ui-compose-demo/
├── app/
│   ├── src/main/java/com/example/a2uidemo/
│   │   ├── a2ui/
│   │   │   ├── protocol/        # A2UI协议定义
│   │   │   ├── parser/          # 消息解析器
│   │   │   ├── renderer/        # 渲染引擎
│   │   │   ├── components/      # 标准组件库
│   │   │   └── ui/              # UI层
│   │   ├── ui/theme/            # Material主题
│   │   ├── DemoViewModel.kt     # ViewModel
│   │   └── MainActivity.kt      # 主活动
│   └── build.gradle.kts
├── README.md                    # 使用说明
├── ARCHITECTURE.md              # 架构设计文档
├── EXAMPLES.md                  # 详细示例
└── build.gradle.kts
```

## 🚀 快速开始

### 环境要求
- Android Studio Hedgehog (2023.1.1+)
- JDK 17
- Android SDK (API 24+)
- Gradle 8.2

### 运行Demo

1. **打开项目**
   ```bash
   # Android Studio中打开项目目录
   File -> Open -> 选择 a2ui-compose-demo
   ```

2. **同步Gradle**
   - 等待Gradle自动同步
   - 如果失败，点击 "Sync Now"

3. **运行应用**
   - 连接Android设备或启动模拟器
   - 点击 Run (Shift + F10)

4. **体验Demo**
   - 点击 "Simple Card" 查看基础卡片
   - 点击 "Form" 查看表单示例
   - 点击 "List" 查看列表渲染

## 💡 使用示例

### 基础用法

```kotlin
// 1. 创建渲染器
val renderer = A2UIRenderer()

// 2. 准备A2UI消息（JSONL格式）
val a2uiMessages = """
{"type":"beginRendering","surfaceId":"demo"}
{"type":"surfaceUpdate","surfaceId":"demo","components":[
  {"id":"root","type":"card","properties":{"child":"content"}},
  {"id":"content","type":"column","properties":{"children":["title","button"]}},
  {"id":"title","type":"text","properties":{"text":"Hello A2UI!","style":"headline"}},
  {"id":"button","type":"button","properties":{"text":"Click Me","action":{"type":"click"}}}
]}
{"type":"dataModelUpdate","surfaceId":"demo","dataModel":{}}
""".trimIndent()

// 3. 解析并处理消息
val messages = A2UIMessageParser.parseMessages(a2uiMessages)
messages.forEach { renderer.processMessage(it) }

// 4. 在Compose中渲染
@Composable
fun MyScreen(renderer: A2UIRenderer) {
    A2UISurface(
        surfaceId = "demo",
        renderer = renderer,
        onAction = { componentId, actionType, context ->
            // 处理用户操作
            println("Action: $actionType on $componentId")
        }
    )
}
```

### 自定义组件

```kotlin
// 创建自定义组件渲染器
class CustomImageRenderer : ComponentRenderer {
    @Composable
    override fun Render(
        component: Component,
        dataModel: JsonObject,
        surfaceState: SurfaceState,
        onAction: (String, String, JsonObject?) -> Unit
    ) {
        val url = resolvePropertyValue(
            component.properties["url"],
            dataModel
        )?.toString() ?: ""
        
        AsyncImage(
            model = url,
            contentDescription = null,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

// 注册到catalog
val catalog = ComponentCatalog().apply {
    // 标准组件
    register("text", TextComponentRenderer())
    register("button", ButtonComponentRenderer())
    // ... 其他标准组件
    
    // 自定义组件
    register("image", CustomImageRenderer())
}
```

## 📊 A2UI协议示例

### 简单卡片
```json
{"type":"beginRendering","surfaceId":"card1"}
{"type":"surfaceUpdate","surfaceId":"card1","components":[
  {"id":"root","type":"card","properties":{"child":"content"}},
  {"id":"content","type":"column","properties":{"children":["title","desc","button"],"spacing":16}},
  {"id":"title","type":"text","properties":{"text":"Welcome","style":"headline"}},
  {"id":"desc","type":"text","properties":{"text":"This is an A2UI card","style":"body"}},
  {"id":"button","type":"button","properties":{"text":"Get Started","action":{"type":"start"}}}
]}
{"type":"dataModelUpdate","surfaceId":"card1","dataModel":{}}
```

### 数据绑定表单
```json
{"type":"beginRendering","surfaceId":"form1"}
{"type":"surfaceUpdate","surfaceId":"form1","components":[
  {"id":"root","type":"column","properties":{"children":["nameField","emailField","submit"]}},
  {"id":"nameField","type":"textField","properties":{"label":"Name","value":{"path":"/name"}}},
  {"id":"emailField","type":"textField","properties":{"label":"Email","value":{"path":"/email"}}},
  {"id":"submit","type":"button","properties":{"text":"Submit","action":{"type":"submit"}}}
]}
{"type":"dataModelUpdate","surfaceId":"form1","dataModel":{"name":"","email":""}}
```

### 动态列表
```json
{"type":"surfaceUpdate","surfaceId":"list1","components":[
  {"id":"list","type":"list","properties":{"items":{"path":"/items"},"itemTemplate":"item"}},
  {"id":"item","type":"row","properties":{"children":["text","btn"]}},
  {"id":"text","type":"text","properties":{"text":{"path":"/title"}}},
  {"id":"btn","type":"button","properties":{"text":"Done","action":{"type":"complete"}}}
]}
{"type":"dataModelUpdate","surfaceId":"list1","dataModel":{
  "items":[
    {"title":"Task 1","done":false},
    {"title":"Task 2","done":true}
  ]
}}
```

## 🏗️ 架构亮点

### 1. 分层架构
```
UI Layer (Compose) → Component Layer → Renderer Layer → Protocol Layer
```

### 2. 邻接表模型
- 扁平化组件存储（Map<ID, Component>）
- 通过ID引用建立父子关系
- 支持高效增量更新
- LLM友好的结构

### 3. 响应式数据流
```
A2UI Message → Parser → Renderer → State Update → Compose Recomposition → UI
```

### 4. 组件注册表模式
- 解耦组件类型和实现
- 运行时可扩展
- 类型安全

## 🔒 安全性

- ✅ **无代码执行** - 纯数据格式，不包含可执行代码
- ✅ **组件白名单** - 只能使用预注册的组件
- ✅ **类型安全** - Kotlin强类型系统保护
- ✅ **数据验证** - JSON schema验证支持

## 📈 性能特性

- ⚡ **细粒度重组** - 只重组变化的组件
- ⚡ **O(1)组件查找** - HashMap存储
- ⚡ **增量更新** - 无需重建整棵树
- ⚡ **懒加载** - 按需解析数据

## 🎨 Material Design 3

完整支持Material 3设计系统：
- 动态颜色主题
- 深色/浅色模式
- Material组件
- 响应式布局

## 📚 文档

- **README.md** - 基础使用说明
- **ARCHITECTURE.md** - 详细架构设计（必读！）
- **EXAMPLES.md** - 20+个完整示例
- 代码注释 - 关键类和函数的详细说明

## 🔄 A2UI协议版本

当前实现：**A2UI v0.8**

支持的消息类型：
- `beginRendering`
- `surfaceUpdate`
- `dataModelUpdate`
- `deleteSurface`

计划支持：
- A2UI v0.9（新的formatString语法）
- 更多标准组件
- 动画支持

## 🛠️ 技术栈

| 技术 | 用途 |
|-----|------|
| Kotlin | 主要编程语言 |
| Jetpack Compose | UI框架 |
| Material 3 | 设计系统 |
| Kotlin Serialization | JSON处理 |
| Coroutines | 异步处理 |
| StateFlow | 响应式数据 |
| ViewModel | 架构组件 |

## 🎯 适用场景

1. **AI助手应用** - 动态生成的对话界面
2. **多代理系统** - 远程代理的UI渲染
3. **低代码平台** - 可视化构建器
4. **动态表单** - 根据上下文生成表单
5. **自适应UI** - 根据数据动态调整界面

## 🌟 项目亮点

### 1. 生产就绪
- 完整的错误处理
- 类型安全的API
- 全面的文档

### 2. 易于扩展
- 插件式组件系统
- 清晰的接口定义
- 丰富的扩展点

### 3. 性能优化
- 最小化重组
- 高效的数据结构
- 懒加载支持

### 4. 开发者友好
- 详细的代码注释
- 完整的示例
- 清晰的架构文档

## 🔮 未来计划

- [ ] 更多标准组件（Image, Checkbox, Switch等）
- [ ] SSE/WebSocket实时连接支持
- [ ] 动画和过渡效果
- [ ] A2UI v0.9支持
- [ ] 主题自定义系统
- [ ] 国际化支持
- [ ] 性能监控工具
- [ ] 可视化调试器

## 📞 支持

- 查看 `ARCHITECTURE.md` 了解详细架构
- 查看 `EXAMPLES.md` 获取更多示例
- 提交Issue报告问题
- 贡献代码和改进

## 📄 许可证

Apache 2.0 License - 与A2UI协议保持一致

## 🙏 致谢

- Google A2UI团队 - 开源的A2UI协议
- Android团队 - Jetpack Compose框架
- 社区贡献者

---

**开始构建你的AI驱动界面吧！** 🚀
