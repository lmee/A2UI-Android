# A2UI Compose渲染引擎架构设计

## 概述

本文档详细说明A2UI Compose渲染引擎的架构设计和实现原理。

## 架构分层

```
┌─────────────────────────────────────────────────┐
│              UI Layer (Compose)                 │
│  ┌───────────────────────────────────────────┐  │
│  │   A2UISurface, A2UIMultiSurfaceView      │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│          Component Rendering Layer              │
│  ┌───────────────────────────────────────────┐  │
│  │  ComponentCatalog, ComponentRenderer      │  │
│  │  Standard Components (Text, Button, etc.) │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│           Rendering Engine Layer                │
│  ┌───────────────────────────────────────────┐  │
│  │  A2UIRenderer, SurfaceState              │  │
│  │  Data Model Resolution                    │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
                      ↓
┌─────────────────────────────────────────────────┐
│            Protocol Layer                       │
│  ┌───────────────────────────────────────────┐  │
│  │  A2UIMessageParser                        │  │
│  │  Message Types (SurfaceUpdate, etc.)      │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
```

## 核心组件详解

### 1. Protocol Layer (协议层)

#### A2UIMessages.kt
定义了A2UI协议的所有消息类型：

**服务端到客户端消息：**
- `BeginRenderingMessage` - 初始化一个新的surface
- `SurfaceUpdateMessage` - 更新组件树
- `DataModelUpdateMessage` - 更新数据模型
- `DeleteSurfaceMessage` - 删除surface

**客户端到服务端消息：**
- `ActionEvent` - 用户交互事件
- `DataModelUpdateEvent` - 数据模型变更事件

**数据结构：**
```kotlin
@Serializable
data class Component(
    val id: String,              // 组件唯一ID
    val type: String,            // 组件类型（对应catalog中的类型）
    val properties: JsonObject   // 组件属性
)
```

#### A2UIMessageParser.kt
负责JSON消息的解析和序列化：
- 使用Kotlin Serialization进行JSON处理
- 支持JSONL（JSON Lines）格式
- 容错处理和错误日志

### 2. Rendering Engine Layer (渲染引擎层)

#### A2UIRenderer.kt
核心渲染引擎，管理所有surface的状态：

**职责：**
1. Surface生命周期管理
2. 组件树维护（使用邻接表模型）
3. 数据模型管理和合并
4. 消息处理和状态更新

**关键数据结构：**
```kotlin
data class SurfaceState(
    val surfaceId: String,
    val components: MutableMap<String, Component>,  // ID -> Component映射
    val dataModel: MutableState<JsonObject>,        // 响应式数据模型
    val rootComponentId: MutableState<String?>      // 根组件ID
)
```

**邻接表模型：**
- 组件树以扁平结构存储（Map<String, Component>）
- 父子关系通过ID引用表示
- 支持高效的局部更新
- LLM友好的数据结构

**数据解析函数：**
```kotlin
fun resolvePropertyValue(property: JsonElement, dataModel: JsonObject): Any?
fun resolveDataModelPath(path: String, dataModel: JsonObject): Any?
```

这些函数处理：
- 字面值（literal values）
- JSON Pointer路径解析（如 "/name", "/items/0/title"）
- 类型转换（String, Boolean, Number, Array, Object）

### 3. Component Rendering Layer (组件渲染层)

#### ComponentCatalog.kt
组件注册表，实现了注册表模式：

```kotlin
class ComponentCatalog {
    private val components: Map<String, ComponentRenderer>
    
    fun register(type: String, renderer: ComponentRenderer)
    fun get(type: String): ComponentRenderer?
}
```

**设计优势：**
- 解耦组件类型和具体实现
- 支持运行时注册自定义组件
- 类型安全的组件访问

#### ComponentRenderer接口
所有组件渲染器必须实现的接口：

```kotlin
interface ComponentRenderer {
    @Composable
    fun Render(
        component: Component,
        dataModel: JsonObject,
        surfaceState: SurfaceState,
        onAction: (componentId: String, actionType: String, context: JsonObject?) -> Unit
    )
}
```

#### StandardComponents.kt
实现了标准A2UI组件库：

1. **TextComponentRenderer**
   - 支持不同样式（headline, title, body）
   - 数据绑定支持

2. **ButtonComponentRenderer**
   - 动作处理
   - 启用/禁用状态
   - 文本数据绑定

3. **ColumnComponentRenderer**
   - 垂直布局容器
   - 子组件递归渲染
   - 可配置间距

4. **RowComponentRenderer**
   - 水平布局容器
   - 子组件递归渲染
   - 可配置间距

5. **CardComponentRenderer**
   - Material卡片容器
   - 单子组件支持
   - 阴影和圆角

6. **TextFieldComponentRenderer**
   - 双向数据绑定
   - 实时数据更新
   - Material设计

7. **ListComponentRenderer**
   - 数据驱动列表
   - 模板化渲染
   - 作用域数据模型

### 4. UI Layer (UI层)

#### A2UISurface.kt
Compose可组合函数，渲染单个surface：

```kotlin
@Composable
fun A2UISurface(
    surfaceId: String,
    renderer: A2UIRenderer,
    onAction: (String, String, JsonObject?) -> Unit
)
```

**特性：**
- 响应式更新（使用Compose State）
- 自动重组当数据变化时
- 错误处理和降级显示

#### A2UIMultiSurfaceView
渲染多个surface的容器：

```kotlin
@Composable
fun A2UIMultiSurfaceView(
    renderer: A2UIRenderer,
    onAction: (surfaceId, componentId, actionType, context) -> Unit
)
```

## 数据流

### 1. 消息处理流程

```
JSON Message (JSONL)
        ↓
A2UIMessageParser.parseMessage()
        ↓
A2UIMessage (sealed class)
        ↓
A2UIRenderer.processMessage()
        ↓
Update SurfaceState
        ↓
Compose Recomposition
        ↓
UI Update
```

### 2. 渲染流程

```
A2UISurface (Composable)
        ↓
Get SurfaceState from Renderer
        ↓
Get Root Component ID
        ↓
A2UIComponentRenderer
        ↓
Lookup ComponentRenderer in Catalog
        ↓
Resolve Properties from Data Model
        ↓
Render Compose UI
        ↓
Recursively Render Children
```

### 3. 用户交互流程

```
User Interaction (e.g., Button Click)
        ↓
onAction callback
        ↓
Create ActionEvent
        ↓
Serialize to JSON
        ↓
Send to Server (in real app)
        ↓
Server processes and may send new SurfaceUpdate
```

## 关键设计决策

### 1. 为什么使用邻接表模型？

**优点：**
- ✅ LLM可以轻松生成扁平的组件列表
- ✅ 支持增量更新（只需添加/更新组件）
- ✅ 无需完整的嵌套JSON
- ✅ 高效的查找（O(1) by ID）

**对比嵌套树：**
- ❌ 嵌套树难以增量更新
- ❌ LLM难以生成深层嵌套结构
- ❌ 部分更新需要复杂的合并逻辑

### 2. 为什么分离数据模型和组件树？

**优点：**
- ✅ 清晰的关注点分离
- ✅ 数据可以独立更新
- ✅ 支持数据绑定模式
- ✅ 减少重复（多个组件可引用同一数据）

### 3. 为什么使用Compose State？

**优点：**
- ✅ 自动UI更新
- ✅ 声明式UI范式
- ✅ 高效的重组
- ✅ 类型安全

### 4. 为什么使用JSON Pointer？

**优点：**
- ✅ 标准化路径语法
- ✅ 支持嵌套对象和数组
- ✅ 简单易懂
- ✅ 与A2UI规范一致

## 性能考虑

### 1. 状态管理
- 使用`MutableStateMap`实现O(1)组件查找
- 最小化状态更新范围
- 只在必要时触发重组

### 2. 渲染优化
- 组件级别的细粒度重组
- 避免不必要的子树渲染
- 使用`remember`缓存计算结果

### 3. 内存管理
- 组件树使用引用而非拷贝
- 及时清理删除的surface
- JSON解析使用流式处理

## 扩展性

### 添加自定义组件

1. 实现`ComponentRenderer`接口
2. 注册到`ComponentCatalog`
3. 在A2UI消息中使用对应的type

示例：
```kotlin
class ImageComponentRenderer : ComponentRenderer {
    @Composable
    override fun Render(...) {
        val url = resolvePropertyValue(component.properties["url"], dataModel)
        AsyncImage(url = url, ...)
    }
}

catalog.register("image", ImageComponentRenderer())
```

### 支持新的消息类型

1. 在`A2UIMessages.kt`中定义消息类
2. 在`A2UIRenderer`中添加处理逻辑
3. 在`A2UIMessageParser`中添加解析逻辑

## 安全性

### 1. 无代码执行
- A2UI是纯数据格式
- 不包含可执行代码
- 所有组件都是预定义的

### 2. 组件白名单
- 只能使用catalog中注册的组件
- 未知组件类型会降级显示
- 防止UI注入攻击

### 3. 数据验证
- JSON schema验证（可选）
- 类型安全的数据访问
- 错误处理和日志

## 测试策略

### 单元测试
- 消息解析器测试
- 数据模型解析测试
- 组件渲染器单独测试

### 集成测试
- 完整的消息处理流程
- Surface生命周期管理
- 用户交互测试

### UI测试
- Compose UI测试
- 屏幕截图测试
- 可访问性测试

## 未来改进方向

1. **性能优化**
   - 虚拟化列表渲染
   - 增量解析大型消息
   - 组件渲染缓存

2. **功能增强**
   - 更多标准组件
   - 动画和过渡
   - 主题化支持
   - 国际化

3. **开发工具**
   - A2UI消息调试器
   - 可视化组件树
   - 性能分析工具

4. **协议支持**
   - A2UI v0.9支持
   - 双向数据流
   - 实时协作

## 总结

本架构设计实现了：
- ✅ 完整的A2UI v0.8协议支持
- ✅ 高性能的Compose渲染引擎
- ✅ 可扩展的组件系统
- ✅ 类型安全的数据处理
- ✅ 清晰的分层架构

遵循了A2UI的核心原则：
- 安全优先
- LLM友好
- 框架无关
- 渐进式渲染
