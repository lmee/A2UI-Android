# 🚀 A2UI Compose - 快速开始指南

## 📦 解压项目

```bash
tar -xzf a2ui-compose-demo.tar.gz
cd a2ui-compose-demo
```

## 🔧 在Android Studio中打开

1. 启动 Android Studio
2. 选择 **File → Open**
3. 导航到 `a2ui-compose-demo` 目录
4. 点击 **OK**
5. 等待 Gradle 同步完成（首次可能需要几分钟）

## ▶️ 运行Demo

### 方式1：使用Android设备
1. 在Android设备上启用"开发者选项"和"USB调试"
2. 用USB线连接设备到电脑
3. 在Android Studio中点击绿色的运行按钮（或按 `Shift + F10`）
4. 选择你的设备

### 方式2：使用Android模拟器
1. 在Android Studio中打开 **Device Manager**（工具栏上的设备图标）
2. 点击 **Create Device**
3. 选择一个设备定义（推荐：Pixel 5）
4. 选择系统镜像（推荐：API 34）
5. 点击 **Finish** 创建模拟器
6. 启动模拟器
7. 点击运行按钮

## 🎮 体验Demo功能

应用启动后，你会看到三个Demo按钮：

### 1. Simple Card
展示基础的卡片布局：
- 标题文本
- 描述文本
- 交互按钮

**技术点：**
- Card组件
- Column布局
- Text样式
- Button动作

### 2. Form
展示表单输入：
- 文本输入框（Name, Email）
- 数据绑定
- 提交按钮

**技术点：**
- TextField组件
- 双向数据绑定
- JSON Pointer路径

### 3. List
展示动态列表：
- 数据驱动列表
- 模板化渲染
- 列表项交互

**技术点：**
- List组件
- itemTemplate
- 数组数据绑定

## 📱 App界面说明

```
┌─────────────────────────────┐
│  A2UI Compose Demo    [🔄] │  ← 顶部栏（刷新按钮清空所有）
├─────────────────────────────┤
│  Load Demo Examples:        │
│  [Simple Card] [Form] [List]│  ← Demo选择按钮
├─────────────────────────────┤
│                             │
│  ┌───────────────────────┐  │
│  │   Surface内容显示区    │  │  ← A2UI渲染的内容
│  │                       │  │
│  └───────────────────────┘  │
│                             │
├─────────────────────────────┤
│  Status: Loaded 3 messages  │  ← 底部状态栏
└─────────────────────────────┘
```

## 🔍 查看代码

### 核心文件位置

```
app/src/main/java/com/example/a2uidemo/
│
├── MainActivity.kt              ← 启动这里！查看Demo数据
│   └── getDemoExample1()        ← Simple Card的A2UI JSON
│   └── getDemoExample2()        ← Form的A2UI JSON
│   └── getDemoExample3()        ← List的A2UI JSON
│
├── a2ui/
│   ├── protocol/
│   │   └── A2UIMessages.kt     ← A2UI协议消息定义
│   │
│   ├── parser/
│   │   └── A2UIMessageParser.kt ← JSON解析器
│   │
│   ├── renderer/
│   │   ├── A2UIRenderer.kt     ← 核心渲染引擎
│   │   └── ComponentCatalog.kt ← 组件注册表
│   │
│   ├── components/
│   │   └── StandardComponents.kt ← 所有标准组件实现
│   │
│   └── ui/
│       └── A2UISurface.kt      ← Surface渲染Composable
│
└── DemoViewModel.kt             ← 应用状态管理
```

## 🎯 快速修改Demo

### 修改Simple Card的文本

1. 打开 `MainActivity.kt`
2. 找到 `getDemoExample1()` 函数
3. 修改JSON中的text属性：

```kotlin
fun getDemoExample1(): String {
    return """
{"type":"beginRendering","surfaceId":"demo1"}
{"type":"surfaceUpdate","surfaceId":"demo1","components":[
  {"id":"root","type":"card","properties":{"child":"content"}},
  {"id":"content","type":"column","properties":{"children":["title","description","button"],"spacing":16}},
  {"id":"title","type":"text","properties":{"text":"你好，A2UI！","style":"headline"}},  ← 修改这里
  {"id":"description","type":"text","properties":{"text":"这是修改后的描述","style":"body"}},  ← 和这里
  {"id":"button","type":"button","properties":{"text":"点击我","action":{"type":"click","data":"demo1"}}}  ← 还有这里
]}
{"type":"dataModelUpdate","surfaceId":"demo1","dataModel":{}}
    """.trimIndent()
}
```

4. 重新运行应用
5. 点击 "Simple Card" 查看更改

### 添加新的Demo

在 `DemoControls` composable中添加新按钮：

```kotlin
Button(
    onClick = { viewModel.loadDemoData(getMyCustomDemo()) },
    modifier = Modifier.weight(1f)
) {
    Text("My Demo")
}
```

然后创建你的自定义Demo函数：

```kotlin
fun getMyCustomDemo(): String {
    return """
{"type":"beginRendering","surfaceId":"custom"}
{"type":"surfaceUpdate","surfaceId":"custom","components":[
  {"id":"root","type":"text","properties":{"text":"我的自定义Demo！","style":"headline"}}
]}
{"type":"dataModelUpdate","surfaceId":"custom","dataModel":{}}
    """.trimIndent()
}
```

## 🔨 常见问题

### Q: Gradle同步失败
**A:** 
1. 检查网络连接
2. 使用 File → Invalidate Caches and Restart
3. 确保已安装JDK 17

### Q: 应用无法运行
**A:**
1. 确保设备/模拟器已连接
2. 检查minSdk是否满足（需要API 24+）
3. 查看Logcat中的错误信息

### Q: 如何查看A2UI消息处理过程
**A:**
在 `A2UIRenderer.kt` 的 `processMessage()` 函数中添加日志：

```kotlin
fun processMessage(message: A2UIMessage) {
    println("Processing message: ${message.type}")  // 添加这行
    when (message) {
        // ...
    }
}
```

### Q: 如何调试组件渲染
**A:**
在 `StandardComponents.kt` 的任何组件Render函数中添加断点或日志：

```kotlin
@Composable
override fun Render(...) {
    println("Rendering ${component.type} with id ${component.id}")  // 添加这行
    // 组件渲染逻辑
}
```

## 📚 下一步

### 学习架构
阅读 `ARCHITECTURE.md` 了解：
- 分层架构设计
- 邻接表模型原理
- 数据流向
- 渲染引擎实现

### 查看更多示例
阅读 `EXAMPLES.md` 获取：
- 20+ 完整示例
- 各种使用场景
- 最佳实践
- 代码集成方法

### 扩展功能
尝试：
1. 添加新的标准组件（Image, Checkbox等）
2. 实现自定义组件
3. 连接到真实的A2UI服务器
4. 添加动画效果

## 🆘 需要帮助？

1. **查看文档**
   - README.md - 基础说明
   - ARCHITECTURE.md - 架构设计
   - EXAMPLES.md - 详细示例

2. **查看代码注释**
   - 所有关键类都有详细注释
   - 函数说明了参数和返回值

3. **参考官方资源**
   - [A2UI官网](https://a2ui.org/)
   - [A2UI GitHub](https://github.com/google/A2UI)
   - [A2UI规范](https://a2ui.org/specification/v0.8-a2ui/)

## ✅ 检查清单

运行前确认：
- [ ] Android Studio已安装（Hedgehog 2023.1.1+）
- [ ] JDK 17已安装
- [ ] Android SDK已安装（API 24+）
- [ ] 设备/模拟器已准备好
- [ ] Gradle同步成功

第一次运行成功后：
- [ ] 测试了三个Demo
- [ ] 查看了MainActivity.kt中的Demo代码
- [ ] 理解了A2UI JSON格式
- [ ] 尝试修改了Demo文本

准备深入学习：
- [ ] 阅读ARCHITECTURE.md
- [ ] 阅读EXAMPLES.md
- [ ] 查看StandardComponents.kt
- [ ] 理解A2UIRenderer.kt

## 🎉 开始探索吧！

现在你已经准备好开始使用A2UI Compose了。祝你构建出色的AI驱动界面！

有问题？查看文档或在GitHub上提Issue。
