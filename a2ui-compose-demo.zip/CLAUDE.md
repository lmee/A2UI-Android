# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a **dual-project** Android application:

1. **Demo App** (`app/`) — A demonstration app that uses DeepSeek API via SSE streaming to generate A2UI JSONL, which is then rendered by the A2UI Compose library.
2. **A2UI Compose Library** (`D:/projects/A2UI/android_compose/`) — A reusable library that parses A2UI protocol messages and renders them as Jetpack Compose UI.

The app and library are separate Gradle modules. The library is included via:
```kotlin
include(":a2ui-compose")
project(":a2ui-compose").projectDir = file("D:/projects/A2UI/android_compose")
```

## Build Commands

```bash
./gradlew assembleDebug          # Build debug APK
./gradlew assembleRelease        # Build release APK
./gradlew :a2ui-compose:dependencies  # Check library dependencies
```

APKs are output to:
- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/apk/release/app-release-unsigned.apk`

## Architecture

### Demo App (`app/`)

```
app/src/main/java/com/example/a2uidemo/
├── MainActivity.kt         # Entry point — demo UI with preset scenarios + AI mode
├── DemoViewModel.kt       # Orchestrates AI requests and manages A2UI renderer state
├── api/
│   ├── DeepSeekClient.kt  # OkHttp SSE streaming client for DeepSeek API
│   └── DeepSeekConfig.kt  # API key, base URL, and request model configuration
└── ui/theme/              # Material 3 theme (Color, Type, Theme)
```

### A2UI Library (`D:/projects/A2UI/android_compose/`)

```
src/main/java/org/a2ui/compose/
├── data/
│   ├── A2UIMessage.kt       # Message types (beginRendering, surfaceUpdate, dataModelUpdate, deleteSurface)
│   ├── DataModelProcessor.kt
│   └── DataModelState.kt
├── protocol/
│   ├── A2UIProtocol.kt          # Core protocol logic
│   ├── A2UIStreamingJsonlProcessor.kt  # Line-by-line SSE JSONL processing
│   ├── A2UIJsonObjectExtractor.kt
│   └── A2UISurfaceLayouts.kt
├── rendering/
│   ├── A2UIRenderer.kt     # Main renderer — processes messages, manages component tree
│   └── ComponentRegistry.kt
├── transport/
│   ├── A2UITransport.kt    # High-level transport abstraction
│   └── NetworkTransport.kt
├── validation/
│   ├── PathValidator.kt       # JSON Pointer path validation
│   └── SafeRegexValidator.kt
├── charts/                   # Chart components (bar, line, pie, gauge, stock)
├── components/               # AudioPlayer, VideoPlayer
├── effects/VisualEffects.kt
├── animation/AnimatedComponents.kt
├── theme/A2UITheme.kt
├── service/A2UIService.kt
├── llm/A2UILlmPrompt.kt
├── example/                  # Demo activities inside the library
└── error/ErrorHandler.kt
```

### Data Flow (AI Mode)

1. User types a prompt → `DemoViewModel` sends it to `DeepSeekClient`
2. `DeepSeekClient` streams SSE from DeepSeek API → raw JSONL lines
3. `A2UIStreamingJsonlProcessor` parses lines incrementally
4. `A2UIRenderer` processes messages → updates component tree via `Snapshot` transactions
5. `A2UISurface` composable renders the component tree reactively

## A2UI Protocol (v0.10)

Message types:
- `beginRendering` — Initialize a surface with a `surfaceId`
- `surfaceUpdate` — Replace or patch the component tree
- `dataModelUpdate` — Update data bindings (supports JSON Pointer paths)
- `deleteSurface` — Remove a surface

Supported components: Text, Button, Column, Row, Card, TextField, CheckBox, Switch, Divider, Spacer, ProgressBar, Icon, List, and charts.

## Key Implementation Notes

- **Rendering updates**: Use `Snapshot` transactions for atomic, batched Compose state updates
- **Streaming**: `A2UIStreamingJsonlProcessor` processes SSE lines one-by-one via `collectLines()` — avoids buffering the full response
- **State management**: `SnapshotStateMap` for components, `StateFlow` for UI state in ViewModels
- **Path validation**: All data model references use `PathValidator` and `SafeRegexValidator` to prevent injection
- **Library vs App**: The demo app (`app/`) is self-contained with its own `DeepSeekClient` for AI streaming. The library (`a2ui-compose`) is framework-agnostic and provides only the rendering engine.

## Tech Stack

| | Version |
|---|---|
| Gradle | 8.11.1 |
| Android Gradle Plugin | 8.7.3 |
| Kotlin | 2.0.21 |
| Compose BOM | 2024.04.00 |
| Min SDK | 24 (app) / 21 (lib) |
| Target SDK | 34 |
| Java Target | JDK 17 |

Key dependencies: `kotlinx-serialization-json`, `okhttp3` + `okhttp-sse`, `coil-compose`, `exoplayer`, `compose-markdown`.

## Testing

Unit tests for the library are in `D:/projects/A2UI/android_compose/src/test/`. The app module does not have dedicated test directories configured.
