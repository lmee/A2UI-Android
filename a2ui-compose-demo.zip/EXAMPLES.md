# A2UI Compose使用示例

本文档提供了各种A2UI使用场景的详细示例。

## 基础示例

### 1. 最简单的文本显示

```json
{"type":"beginRendering","surfaceId":"simple"}
{"type":"surfaceUpdate","surfaceId":"simple","components":[
  {"id":"text1","type":"text","properties":{"text":"Hello A2UI!"}}
]}
{"type":"dataModelUpdate","surfaceId":"simple","dataModel":{}}
```

### 2. 带样式的文本

```json
{"type":"surfaceUpdate","surfaceId":"simple","components":[
  {"id":"headline","type":"text","properties":{"text":"Large Heading","style":"headline"}},
  {"id":"title","type":"text","properties":{"text":"Medium Title","style":"title"}},
  {"id":"body","type":"text","properties":{"text":"Normal body text","style":"body"}}
]}
```

## 布局示例

### 3. 垂直布局（Column）

```json
{"type":"beginRendering","surfaceId":"layout1"}
{"type":"surfaceUpdate","surfaceId":"layout1","components":[
  {"id":"root","type":"column","properties":{
    "children":["item1","item2","item3"],
    "spacing":16
  }},
  {"id":"item1","type":"text","properties":{"text":"First item"}},
  {"id":"item2","type":"text","properties":{"text":"Second item"}},
  {"id":"item3","type":"text","properties":{"text":"Third item"}}
]}
{"type":"dataModelUpdate","surfaceId":"layout1","dataModel":{}}
```

### 4. 水平布局（Row）

```json
{"type":"surfaceUpdate","surfaceId":"layout2","components":[
  {"id":"root","type":"row","properties":{
    "children":["left","center","right"],
    "spacing":8
  }},
  {"id":"left","type":"text","properties":{"text":"Left"}},
  {"id":"center","type":"text","properties":{"text":"Center"}},
  {"id":"right","type":"text","properties":{"text":"Right"}}
]}
```

### 5. 嵌套布局

```json
{"type":"surfaceUpdate","surfaceId":"nested","components":[
  {"id":"root","type":"column","properties":{"children":["header","content","footer"]}},
  {"id":"header","type":"text","properties":{"text":"Header","style":"headline"}},
  {"id":"content","type":"row","properties":{"children":["left","right"]}},
  {"id":"left","type":"text","properties":{"text":"Left Column"}},
  {"id":"right","type":"text","properties":{"text":"Right Column"}},
  {"id":"footer","type":"text","properties":{"text":"Footer"}}
]}
```

## 交互示例

### 6. 简单按钮

```json
{"type":"surfaceUpdate","surfaceId":"button","components":[
  {"id":"btn1","type":"button","properties":{
    "text":"Click Me",
    "action":{"type":"buttonClick","message":"Button was clicked!"}
  }}
]}
```

### 7. 禁用/启用的按钮

```json
{"type":"surfaceUpdate","surfaceId":"button","components":[
  {"id":"btn1","type":"button","properties":{
    "text":"Enabled Button",
    "enabled":true,
    "action":{"type":"click"}
  }},
  {"id":"btn2","type":"button","properties":{
    "text":"Disabled Button",
    "enabled":false,
    "action":{"type":"click"}
  }}
]}
```

## 数据绑定示例

### 8. 从数据模型显示文本

```json
{"type":"surfaceUpdate","surfaceId":"databinding","components":[
  {"id":"greeting","type":"text","properties":{
    "text":{"path":"/message"}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"databinding","dataModel":{
  "message":"Hello from data model!"
}}
```

### 9. 动态更新数据

初始状态：
```json
{"type":"dataModelUpdate","surfaceId":"dynamic","dataModel":{
  "counter":0
}}
```

更新后：
```json
{"type":"dataModelUpdate","surfaceId":"dynamic","dataModel":{
  "counter":5
}}
```

### 10. 嵌套数据访问

```json
{"type":"surfaceUpdate","surfaceId":"nested-data","components":[
  {"id":"name","type":"text","properties":{"text":{"path":"/user/name"}}},
  {"id":"email","type":"text","properties":{"text":{"path":"/user/email"}}},
  {"id":"age","type":"text","properties":{"text":{"path":"/user/age"}}}
]}
{"type":"dataModelUpdate","surfaceId":"nested-data","dataModel":{
  "user":{
    "name":"Alice",
    "email":"alice@example.com",
    "age":30
  }
}}
```

## 表单示例

### 11. 基础表单

```json
{"type":"beginRendering","surfaceId":"form"}
{"type":"surfaceUpdate","surfaceId":"form","components":[
  {"id":"root","type":"card","properties":{"child":"form"}},
  {"id":"form","type":"column","properties":{
    "children":["title","nameField","emailField","submitBtn"],
    "spacing":16
  }},
  {"id":"title","type":"text","properties":{
    "text":"Registration Form",
    "style":"title"
  }},
  {"id":"nameField","type":"textField","properties":{
    "label":"Full Name",
    "value":{"path":"/formData/name"}
  }},
  {"id":"emailField","type":"textField","properties":{
    "label":"Email Address",
    "value":{"path":"/formData/email"}
  }},
  {"id":"submitBtn","type":"button","properties":{
    "text":"Submit",
    "action":{"type":"submit","form":"registration"}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"form","dataModel":{
  "formData":{
    "name":"",
    "email":""
  }
}}
```

### 12. 带验证的表单

```json
{"type":"surfaceUpdate","surfaceId":"validated-form","components":[
  {"id":"root","type":"column","properties":{"children":["field","error","button"]}},
  {"id":"field","type":"textField","properties":{
    "label":"Email",
    "value":{"path":"/email"}
  }},
  {"id":"error","type":"text","properties":{
    "text":{"path":"/emailError"}
  }},
  {"id":"button","type":"button","properties":{
    "text":"Submit",
    "enabled":{"path":"/isValid"},
    "action":{"type":"submit"}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"validated-form","dataModel":{
  "email":"",
  "emailError":"",
  "isValid":false
}}
```

## 列表示例

### 13. 简单列表

```json
{"type":"beginRendering","surfaceId":"list"}
{"type":"surfaceUpdate","surfaceId":"list","components":[
  {"id":"root","type":"column","properties":{"children":["title","list"]}},
  {"id":"title","type":"text","properties":{"text":"Todo List","style":"headline"}},
  {"id":"list","type":"list","properties":{
    "items":{"path":"/todos"},
    "itemTemplate":"todoItem"
  }},
  {"id":"todoItem","type":"row","properties":{"children":["todoText","doneBtn"]}},
  {"id":"todoText","type":"text","properties":{"text":{"path":"/title"}}},
  {"id":"doneBtn","type":"button","properties":{
    "text":"✓",
    "action":{"type":"markDone"}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"list","dataModel":{
  "todos":[
    {"id":"1","title":"Learn A2UI","done":false},
    {"id":"2","title":"Build app","done":false},
    {"id":"3","title":"Deploy","done":false}
  ]
}}
```

### 14. 复杂列表项

```json
{"type":"surfaceUpdate","surfaceId":"product-list","components":[
  {"id":"list","type":"list","properties":{
    "items":{"path":"/products"},
    "itemTemplate":"productCard"
  }},
  {"id":"productCard","type":"card","properties":{"child":"productContent"}},
  {"id":"productContent","type":"column","properties":{
    "children":["productName","productPrice","productDesc","buyBtn"],
    "spacing":8
  }},
  {"id":"productName","type":"text","properties":{
    "text":{"path":"/name"},
    "style":"title"
  }},
  {"id":"productPrice","type":"text","properties":{
    "text":{"path":"/price"}
  }},
  {"id":"productDesc","type":"text","properties":{
    "text":{"path":"/description"}
  }},
  {"id":"buyBtn","type":"button","properties":{
    "text":"Add to Cart",
    "action":{"type":"addToCart","productId":{"path":"/id"}}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"product-list","dataModel":{
  "products":[
    {
      "id":"p1",
      "name":"Laptop",
      "price":"$999",
      "description":"High-performance laptop"
    },
    {
      "id":"p2",
      "name":"Mouse",
      "price":"$29",
      "description":"Wireless mouse"
    }
  ]
}}
```

## 卡片示例

### 15. 信息卡片

```json
{"type":"surfaceUpdate","surfaceId":"info-card","components":[
  {"id":"root","type":"card","properties":{"child":"content"}},
  {"id":"content","type":"column","properties":{
    "children":["title","subtitle","body","actions"],
    "spacing":12
  }},
  {"id":"title","type":"text","properties":{
    "text":"Card Title",
    "style":"headline"
  }},
  {"id":"subtitle","type":"text","properties":{
    "text":"Subtitle text",
    "style":"title"
  }},
  {"id":"body","type":"text","properties":{
    "text":"This is the main content of the card.",
    "style":"body"
  }},
  {"id":"actions","type":"row","properties":{
    "children":["btn1","btn2"],
    "spacing":8
  }},
  {"id":"btn1","type":"button","properties":{
    "text":"Action 1",
    "action":{"type":"action1"}
  }},
  {"id":"btn2","type":"button","properties":{
    "text":"Action 2",
    "action":{"type":"action2"}
  }}
]}
```

### 16. 多卡片布局

```json
{"type":"surfaceUpdate","surfaceId":"multi-cards","components":[
  {"id":"root","type":"column","properties":{
    "children":["card1","card2","card3"],
    "spacing":16
  }},
  {"id":"card1","type":"card","properties":{"child":"content1"}},
  {"id":"content1","type":"text","properties":{"text":"Card 1"}},
  {"id":"card2","type":"card","properties":{"child":"content2"}},
  {"id":"content2","type":"text","properties":{"text":"Card 2"}},
  {"id":"card3","type":"card","properties":{"child":"content3"}},
  {"id":"content3","type":"text","properties":{"text":"Card 3"}}
]}
```

## 实际应用场景

### 17. 用户资料页面

```json
{"type":"beginRendering","surfaceId":"profile"}
{"type":"surfaceUpdate","surfaceId":"profile","components":[
  {"id":"root","type":"column","properties":{
    "children":["profileCard","actionsCard"],
    "spacing":16
  }},
  {"id":"profileCard","type":"card","properties":{"child":"profileContent"}},
  {"id":"profileContent","type":"column","properties":{
    "children":["name","email","bio"],
    "spacing":8
  }},
  {"id":"name","type":"text","properties":{
    "text":{"path":"/user/name"},
    "style":"headline"
  }},
  {"id":"email","type":"text","properties":{
    "text":{"path":"/user/email"}
  }},
  {"id":"bio","type":"text","properties":{
    "text":{"path":"/user/bio"}
  }},
  {"id":"actionsCard","type":"card","properties":{"child":"actions"}},
  {"id":"actions","type":"row","properties":{
    "children":["editBtn","logoutBtn"],
    "spacing":8
  }},
  {"id":"editBtn","type":"button","properties":{
    "text":"Edit Profile",
    "action":{"type":"editProfile"}
  }},
  {"id":"logoutBtn","type":"button","properties":{
    "text":"Logout",
    "action":{"type":"logout"}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"profile","dataModel":{
  "user":{
    "name":"John Doe",
    "email":"john@example.com",
    "bio":"Software developer passionate about AI"
  }
}}
```

### 18. 购物车

```json
{"type":"beginRendering","surfaceId":"cart"}
{"type":"surfaceUpdate","surfaceId":"cart","components":[
  {"id":"root","type":"column","properties":{
    "children":["header","itemList","total","checkoutBtn"],
    "spacing":16
  }},
  {"id":"header","type":"text","properties":{
    "text":"Shopping Cart",
    "style":"headline"
  }},
  {"id":"itemList","type":"list","properties":{
    "items":{"path":"/cartItems"},
    "itemTemplate":"cartItem"
  }},
  {"id":"cartItem","type":"card","properties":{"child":"itemContent"}},
  {"id":"itemContent","type":"row","properties":{
    "children":["itemInfo","removeBtn"],
    "spacing":8
  }},
  {"id":"itemInfo","type":"column","properties":{
    "children":["itemName","itemPrice"]
  }},
  {"id":"itemName","type":"text","properties":{
    "text":{"path":"/name"},
    "style":"title"
  }},
  {"id":"itemPrice","type":"text","properties":{
    "text":{"path":"/price"}
  }},
  {"id":"removeBtn","type":"button","properties":{
    "text":"Remove",
    "action":{"type":"removeItem","itemId":{"path":"/id"}}
  }},
  {"id":"total","type":"text","properties":{
    "text":{"path":"/totalPrice"},
    "style":"headline"
  }},
  {"id":"checkoutBtn","type":"button","properties":{
    "text":"Checkout",
    "action":{"type":"checkout"}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"cart","dataModel":{
  "cartItems":[
    {"id":"1","name":"Laptop","price":"$999","quantity":1},
    {"id":"2","name":"Mouse","price":"$29","quantity":2}
  ],
  "totalPrice":"$1057"
}}
```

### 19. 天气应用

```json
{"type":"beginRendering","surfaceId":"weather"}
{"type":"surfaceUpdate","surfaceId":"weather","components":[
  {"id":"root","type":"card","properties":{"child":"content"}},
  {"id":"content","type":"column","properties":{
    "children":["location","temp","description","forecast"],
    "spacing":16
  }},
  {"id":"location","type":"text","properties":{
    "text":{"path":"/location"},
    "style":"headline"
  }},
  {"id":"temp","type":"text","properties":{
    "text":{"path":"/temperature"},
    "style":"title"
  }},
  {"id":"description","type":"text","properties":{
    "text":{"path":"/description"}
  }},
  {"id":"forecast","type":"list","properties":{
    "items":{"path":"/forecast"},
    "itemTemplate":"forecastItem"
  }},
  {"id":"forecastItem","type":"row","properties":{
    "children":["day","forecastTemp"]
  }},
  {"id":"day","type":"text","properties":{
    "text":{"path":"/day"}
  }},
  {"id":"forecastTemp","type":"text","properties":{
    "text":{"path":"/temp"}
  }}
]}
{"type":"dataModelUpdate","surfaceId":"weather","dataModel":{
  "location":"San Francisco",
  "temperature":"72°F",
  "description":"Partly cloudy",
  "forecast":[
    {"day":"Tomorrow","temp":"75°F"},
    {"day":"Thursday","temp":"70°F"},
    {"day":"Friday","temp":"68°F"}
  ]
}}
```

## 渐进式更新示例

### 20. 增量添加组件

初始状态：
```json
{"type":"beginRendering","surfaceId":"progressive"}
{"type":"surfaceUpdate","surfaceId":"progressive","components":[
  {"id":"root","type":"column","properties":{"children":["title"],"spacing":8}},
  {"id":"title","type":"text","properties":{"text":"Loading...","style":"headline"}}
]}
```

第一次更新（添加内容）：
```json
{"type":"surfaceUpdate","surfaceId":"progressive","components":[
  {"id":"root","type":"column","properties":{"children":["title","content"],"spacing":8}},
  {"id":"content","type":"text","properties":{"text":"Content loaded!"}}
]}
```

第二次更新（添加按钮）：
```json
{"type":"surfaceUpdate","surfaceId":"progressive","components":[
  {"id":"root","type":"column","properties":{"children":["title","content","button"],"spacing":8}},
  {"id":"button","type":"button","properties":{"text":"Click Me","action":{"type":"click"}}}
]}
```

## 代码集成示例

### Kotlin代码示例

```kotlin
// 创建渲染器
val renderer = A2UIRenderer()

// 加载A2UI消息
val jsonLines = """
{"type":"beginRendering","surfaceId":"demo"}
{"type":"surfaceUpdate","surfaceId":"demo","components":[...]}
{"type":"dataModelUpdate","surfaceId":"demo","dataModel":{...}}
""".trimIndent()

// 解析并处理消息
val messages = A2UIMessageParser.parseMessages(jsonLines)
messages.forEach { message ->
    renderer.processMessage(message)
}

// 在Compose中渲染
@Composable
fun MyScreen() {
    A2UISurface(
        surfaceId = "demo",
        renderer = renderer,
        onAction = { componentId, actionType, context ->
            // 处理用户操作
            when (actionType) {
                "click" -> handleClick(componentId)
                "submit" -> handleSubmit(context)
                else -> println("Unknown action: $actionType")
            }
        }
    )
}
```

## 最佳实践

1. **组件ID命名**
   - 使用描述性名称（如 "submitButton" 而非 "btn1"）
   - 保持一致的命名约定

2. **数据模型组织**
   - 使用嵌套对象组织相关数据
   - 避免过深的嵌套（建议不超过3层）

3. **性能优化**
   - 复用组件定义（通过模板）
   - 最小化数据模型更新
   - 使用增量更新而非完全替换

4. **错误处理**
   - 提供默认值
   - 验证数据模型路径
   - 优雅降级

5. **用户体验**
   - 合理的间距（spacing）
   - 一致的样式
   - 清晰的层次结构
