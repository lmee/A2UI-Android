package com.example.a2uidemo.api

object DeepSeekConfig {
    const val BASE_URL = "https://api.deepseek.com/chat/completions"
    const val API_KEY = "xxx"
    const val MODEL = "deepseek-chat"
    const val MAX_TOKENS = 4096
    const val TEMPERATURE = 0.7
}
