package com.example.a2uidemo.api

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.sse.EventSource
import okhttp3.sse.EventSourceListener
import okhttp3.sse.EventSources

object DeepSeekClient {

    private val client = OkHttpClient.Builder()
        .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    private val json = Json { ignoreUnknownKeys = true }

    fun streamChat(userMessage: String, systemPrompt: String): Flow<String> = callbackFlow {
        val requestBody = buildJsonObject {
            put("model", DeepSeekConfig.MODEL)
            put("max_tokens", DeepSeekConfig.MAX_TOKENS)
            put("temperature", DeepSeekConfig.TEMPERATURE)
            put("stream", true)
            putJsonArray("messages") {
                addJsonObject {
                    put("role", "system")
                    put("content", systemPrompt)
                }
                addJsonObject {
                    put("role", "user")
                    put("content", userMessage)
                }
            }
        }.toString()

        val request = Request.Builder()
            .url(DeepSeekConfig.BASE_URL)
            .header("Authorization", "Bearer ${DeepSeekConfig.API_KEY}")
            .header("Accept", "text/event-stream")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()
        val listener = object : EventSourceListener() {
            override fun onEvent(eventSource: EventSource, id: String?, type: String?, data: String) {
                if (data.trim() == "[DONE]") {
                    close()
                    return
                }
                try {
                    val jsonObj = json.parseToJsonElement(data).jsonObject
                    val content = jsonObj["choices"]
                        ?.jsonArray?.getOrNull(0)
                        ?.jsonObject?.get("delta")
                        ?.jsonObject?.get("content")
                        ?.jsonPrimitive?.content
                    if (content != null) {
                        trySend(content)
                    }
                } catch (_: Exception) { }
            }

            override fun onFailure(eventSource: EventSource, t: Throwable?, response: Response?) {
                val msg = t?.message ?: response?.message ?: "Unknown error"
                close(Exception(msg))
            }

            override fun onClosed(eventSource: EventSource) {
                close()
            }
        }

        val eventSource = EventSources.createFactory(client)
            .newEventSource(request, listener)

        awaitClose { eventSource.cancel() }
    }
}
