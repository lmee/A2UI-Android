package com.example.a2uidemo

import androidx.compose.runtime.snapshots.Snapshot
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.a2uidemo.api.DeepSeekClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.launch
import org.a2ui.compose.rendering.A2UIRenderer

data class ChatMessage(
    val role: String,
    val content: String,
    val isA2UI: Boolean = false
)

enum class UiState { IDLE, LOADING, ERROR }

enum class PresetScenario(val label: String, val prompt: String) {
    WEATHER("天气卡片", "生成一个天气预报卡片，显示城市名称（北京）、当前温度（25°C）、天气状况（晴）、湿度（45%）和风速（3级）。"),
    PROFILE("用户资料表单", "生成一个用户资料编辑表单，包含姓名、邮箱、手机号输入框，以及一个性别选择开关和一个\"接收通知\"复选框，最后有保存按钮。"),
    TASKS("任务列表", "生成一个待办任务列表，包含5个任务项，每个任务有标题、完成状态复选框，底部显示完成进度条。"),
    DASHBOARD("仪表盘", "生成一个简单的数据仪表盘，显示今日访问量、新增用户、订单数量三个指标卡片，每个卡片包含标题、数值和一个进度条。")
}

private const val A2UI_SYSTEM_PROMPT = """你是一个A2UI协议生成器。用户会描述他们想要的UI界面，你需要生成符合A2UI v0.10协议的JSONL消息。

A2UI协议使用JSONL格式（每行一个JSON对象），包含以下消息类型：

1. createSurface: 初始化一个surface
   {"version":"v0.10","createSurface":{"surfaceId":"main","catalogId":"standard"}}

2. updateComponents: 更新surface上的组件（可以发送多次，每次添加部分组件）
   {"version":"v0.10","updateComponents":{"surfaceId":"main","components":[...]}}

3. updateDataModel: 更新数据模型
   {"version":"v0.10","updateDataModel":{"surfaceId":"main","path":"/","value":{...}}}

可用的组件类型（component字段值）：
- Text: 文本，属性: text(字符串或{path:"/xxx"}), variant("h1"|"h2"|"subtitle"|"body"|"caption")
- Button: 按钮，属性: text(字符串或{path:"/xxx"}), variant("primary"|"secondary"|"text"), action:{event:{name:"xxx",context:{}}}
- Column: 垂直布局，属性: children:{"array":["id1","id2"]}, justify("start"|"center"|"spaceBetween"), align("start"|"center"|"stretch")
- Row: 水平布局，属性: children:{"array":["id1","id2"]}, justify, align
- Card: 卡片容器，属性: child:"childId"
- TextField: 输入框，属性: label(字符串), value:{path:"/dataPath"}, placeholder(字符串)
- CheckBox: 复选框，属性: label(字符串), value:{path:"/boolPath"}
- Switch: 开关，属性: label(字符串), value:{path:"/boolPath"}
- Divider: 分割线
- Spacer: 间距
- ProgressBar: 进度条，属性: value:{path:"/progressPath"}
- Icon: 图标，属性: name(字符串如"star"|"check"|"info")

完整示例：
{"version":"v0.10","createSurface":{"surfaceId":"main","catalogId":"standard"}}
{"version":"v0.10","updateComponents":{"surfaceId":"main","components":[{"id":"root","component":"Card","child":"content"},{"id":"content","component":"Column","children":{"array":["title","desc"]}}]}}
{"version":"v0.10","updateComponents":{"surfaceId":"main","components":[{"id":"title","component":"Text","text":"Hello","variant":"h2"},{"id":"desc","component":"Text","text":{"path":"/description"},"variant":"body"}]}}
{"version":"v0.10","updateDataModel":{"surfaceId":"main","path":"/","value":{"description":"World"}}}

重要规则：
- 每行输出一个完整的JSON对象，不要换行
- 每个JSON必须包含 "version":"v0.10"
- surfaceId 统一使用 "main"
- 每个组件必须有唯一的 id
- 根组件的 id 必须是 "root"
- children 必须用 {"array":["id1","id2"]} 格式，不能用纯数组
- 数据绑定用 {path:"/xxx"} 格式
- 第一行输出 createSurface
- 然后分多次输出 updateComponents，每次2-4个组件，实现渐进式渲染
- 先输出根布局组件（id为root），再逐步输出子组件
- 最后输出 updateDataModel
- 只输出JSONL内容，不要输出任何解释文字、markdown标记或代码块标记"""

class DemoViewModel : ViewModel() {
    val renderer = A2UIRenderer()

    private val _uiState = MutableStateFlow(UiState.IDLE)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun sendMessage(userInput: String) {
        if (userInput.isBlank() || _uiState.value == UiState.LOADING) return

        renderer.dispose()
        _uiState.value = UiState.LOADING
        _errorMessage.value = null

        viewModelScope.launch(Dispatchers.Default) {
            val lineBuffer = StringBuilder()
            try {
                DeepSeekClient.streamChat(userInput, A2UI_SYSTEM_PROMPT)
                    .buffer(64)
                    .collect { delta ->
                        lineBuffer.append(delta)
                        val content = lineBuffer.toString()
                        val lastNewline = content.lastIndexOf('\n')
                        if (lastNewline >= 0) {
                            val completePart = content.substring(0, lastNewline)
                            lineBuffer.clear()
                            lineBuffer.append(content.substring(lastNewline + 1))
                            val lines = completePart.split('\n')
                            // Batch all complete lines into a single snapshot transaction
                            // so Compose sees one atomic update instead of N separate ones
                            Snapshot.withMutableSnapshot {
                                for (line in lines) {
                                    processLine(line)
                                }
                            }
                        }
                    }
                // Process any remaining content
                val remaining = lineBuffer.toString().trim()
                if (remaining.isNotEmpty()) {
                    Snapshot.withMutableSnapshot {
                        processLine(remaining)
                    }
                }
                _uiState.value = UiState.IDLE
            } catch (e: Exception) {
                _uiState.value = UiState.ERROR
                _errorMessage.value = e.message ?: "请求失败"
            }
        }
    }

    private fun processLine(line: String) {
        val trimmed = line.trim()
        if (trimmed.startsWith("{")) {
            renderer.processMessage(trimmed)
        }
    }

    fun sendPresetScenario(scenario: PresetScenario) {
        sendMessage(scenario.prompt)
    }

    fun clearAll() {
        renderer.dispose()
        _uiState.value = UiState.IDLE
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        renderer.dispose()
    }
}
