package com.example.a2uidemo.ui.theme

import androidx.compose.ui.graphics.Color

// Google-style neutral + blue palette
val Blue80 = Color(0xFF8AB4F8)
val BlueGrey80 = Color(0xFFC4C7C5)
val Neutral80 = Color(0xFFE8EAED)

val Blue40 = Color(0xFF1B6EF3)
val BlueGrey40 = Color(0xFF5F6368)
val Neutral40 = Color(0xFF3C4043)
