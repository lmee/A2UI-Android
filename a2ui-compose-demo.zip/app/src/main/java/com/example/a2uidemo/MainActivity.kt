package com.example.a2uidemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.a2uidemo.ui.theme.A2UIComposeDemoTheme
import org.a2ui.compose.rendering.A2UIRenderer

class MainActivity : ComponentActivity() {
    private val viewModel: DemoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            A2UIComposeDemoTheme {
                DemoScreen(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DemoScreen(viewModel: DemoViewModel) {
    val renderer = viewModel.renderer
    val uiState by viewModel.uiState.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("A2UI DeepSeek Demo") },
                actions = {
                    IconButton(onClick = { viewModel.clearAll() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Clear")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            Column {
                PresetScenarioBar(
                    enabled = uiState != UiState.LOADING,
                    onScenarioClick = { viewModel.sendPresetScenario(it) }
                )
                ChatInputBar(
                    enabled = uiState != UiState.LOADING,
                    onSend = { viewModel.sendMessage(it) }
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            if (uiState == UiState.ERROR && errorMessage != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Text(
                        text = errorMessage ?: "",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                }
            }

            if (uiState == UiState.LOADING) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            // A2UI render area
            A2UIRenderArea(
                renderer = renderer,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun A2UIRenderArea(
    renderer: A2UIRenderer,
    modifier: Modifier = Modifier
) {
    val surfaceIds = renderer.getAllSurfaceIds()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        surfaceIds.forEach { surfaceId ->
            RenderSurface(renderer, surfaceId)
        }

        if (surfaceIds.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "选择预设场景或输入描述来生成UI",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun RenderSurface(renderer: A2UIRenderer, surfaceId: String) {
    // derivedStateOf: only recompose when root component reference actually changes,
    // NOT when other components are added to the surface
    val context by remember(surfaceId) {
        derivedStateOf { renderer.getSurfaceContext(surfaceId) }
    }
    val rootComponent by remember(surfaceId) {
        derivedStateOf { renderer.getComponent(surfaceId, "root") }
    }

    if (context != null && rootComponent != null) {
        key(rootComponent) {
            renderer.registry.render(rootComponent!!, context!!)
        }
    }
}

@Composable
fun PresetScenarioBar(
    enabled: Boolean,
    onScenarioClick: (PresetScenario) -> Unit
) {
    Surface(tonalElevation = 0.dp) {
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(PresetScenario.entries) { scenario ->
                AssistChip(
                    onClick = { onScenarioClick(scenario) },
                    label = { Text(scenario.label) },
                    enabled = enabled
                )
            }
        }
    }
}

@Composable
fun ChatInputBar(
    enabled: Boolean,
    onSend: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }

    Column {
        HorizontalDivider(thickness = 0.5.dp)
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("描述你想要的UI...") },
                enabled = enabled,
                singleLine = true
            )
            IconButton(
                onClick = {
                    if (text.isNotBlank()) {
                        onSend(text)
                        text = ""
                    }
                },
                enabled = enabled && text.isNotBlank()
            ) {
                Icon(Icons.Default.Send, contentDescription = "发送")
            }
        }
    }
}
