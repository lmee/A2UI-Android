package com.example.a2uidemo.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
